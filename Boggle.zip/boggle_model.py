from typing import Callable
from boggle_board_randomizer import randomize_board
import ex11_utils

LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'


class BoggleModel:
    WORDS = ex11_utils.words
    board: list
    words_found: dict
    current_word: str
    current_clicked: tuple
    current_path: list
    score: int
    stop: 'stop'
    press: str

    def __init__(self,board) -> None:
        self.board = board
        self.current_path = []
    def type_in(self,clicked):
        #function that works according to the value of the cliked button
        letter, row, col, button = clicked
        if letter == "PRESS":
            #try to add the word the the list of words found or make the current_word = 0
            self.submit_word(self.board)
            return
        elif letter == "START":
            self.start_new_game()
            return
        self.current_clicked = (row, col)
        self.current_path.append((row, col))
        self.current_word += self.board[row][col]
        return
    def start_new_game(self):
        # first attributes of the boggle model
        self.words_found = {}
        self.current_word = ''
        self.current_clicked = ()
        self.current_path = []
        self.score = 0

    def submit_word(self, board):
        # function that checks if the word path is valid and if the word is in our dictionnary
        if self.current_word == ex11_utils.is_valid_path(self.board, self.current_path, self.WORDS):
            if self.current_word not in self.words_found.keys():
                self.words_found[self.current_word] = len(self.current_path) ** 2
            else:
                if len(self.current_path)**2 > self.words_found[self.current_word]:
                    self.words_found[self.current_word] = len(self.current_path) ** 2
            self.score_game(self.board)
        # if the word is not in our dictonnary, current_word is deleted and we start a new word.
        self.current_word = ''
        self.current_path = []

    def score_game(self, board):
        # function that gives the score of the game
        score = 0
        for key in self.words_found:
            score += self.words_found[key]
        self.score = score

    def get_score(self):
        return self.score

    def get_board(self):
        return self.board

    def get_display(self):
        return self.current_word

    def stop_before_timer(self):
        return self.start_new_game()

    def print_words_found(self):
        res = ""
        for key in self.words_found.keys():
            res += key
            res += "\n"
        res += "SCORE: " + str(self.score)
        return res
