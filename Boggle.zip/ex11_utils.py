import copy
from typing import List, Tuple, Iterable, Optional


Board = List[List[str]]
Path = List[Tuple[int, int]]
import os
file_path='boggle_dict.txt'
if os.path.exists(file_path):
    with open('boggle_dict.txt', 'r', encoding='utf-8') as foalder:
        words = [word.strip() for word in foalder.readlines()]




def find_all_valid_neighbors(board, row, col):
    result = []
    for i in range(-1, 2):
        for j in range(-1,2):
            if i==0 and j==0:
                continue
            new_row, new_col = row+i, col+j
            if 0 <= new_row < len(board) and 0 <= new_col < len(board):
                result.append((new_row, new_col))
    return result

def is_valid_path(board: Board, path: Path, words: Iterable[str]) -> Optional[str]:
    word = ""
    # row = -1
    # col = -1
    if len(path) == 0:
        return
    for i in range(1,len(path)):
        row = path[i][0]
        col = path[i][1]

        prev_row = path[i-1][0]
        prev_col = path[i-1][1]

        if 0 <= prev_row < len(board) and 0 <= prev_col < len(board[0]):
            if (prev_row, prev_col) in find_all_valid_neighbors(board, row, col):
                word += board[prev_row][prev_col]

                continue
            else:
                return
        else:
            return
    row = path[len(path)-1][0]
    col = path[len(path)-1][1]
    if row < 0 or row >= len(board) or col < 0 or col >= len(board[0]):
        return
    if len(path) > 0:
       word += board[path[len(path)-1][0]][path[len(path)-1][1]]
    if word in words:
        return word


def find_index(board,value):
    lst=[]
    for i in range(len(board)):
        for j in range(len(board[0])):
            for k in range(1,len(value)+1):
                if board[i][j] == value[0:k]:
                    lst.append((i, j))
    return lst


def check(board,row,col,word,new, words,n,total):
    if word == '':
        if is_valid_path(board, new, words) and len(new) == n:
            total.append(copy.deepcopy(new))
        return

    if row == len(board) or col == len(board[0]):
        return

    for neighbor in find_all_valid_neighbors(board, row, col):
        if board[neighbor[0]][neighbor[1]] == word[0: len(board[neighbor[0]][neighbor[1]])]:
            if neighbor in new:
                continue
            new.append(neighbor)
            check(board, neighbor[0], neighbor[1], word[len(board[neighbor[0]][neighbor[1]]):], new, words, n,total)
            new.pop()
    return


def find_length_n_paths(n: int, board: Board, words: Iterable[str]) -> List[Path]:
    new = []
    total = []
    for word in words:
        if len(word) >=n:
            lst = find_index(board, word)
        else:
            lst = find_index(board, word[0])

        if lst:
            for coordinate in lst:
                row = coordinate[0]
                col = coordinate[1]
                new.append((row, col))
                check(board, row, col, word[len(board[row][col]):], new, words, n, total)
                new = []
    return total


def check_length_n(board,row,col,word,new, words,n,total):
    if word == '':
        if is_valid_path(board, new, words):
            total.append(copy.deepcopy(new))
        return

    if row == len(board) or col == len(board[0]):
        return

    for neighbor in find_all_valid_neighbors(board, row, col):
        if board[neighbor[0]][neighbor[1]] == word[0: len(board[neighbor[0]][neighbor[1]])]:
            if neighbor in new:
                continue
            new.append(neighbor)
            check_length_n(board, neighbor[0], neighbor[1], word[len(board[neighbor[0]][neighbor[1]]):], new, words, n,total)
            new.pop()
    return


def find_length_n_words(n: int, board: Board, words: Iterable[str]) -> List[Path]:
    new = []
    total=[]
    for word in words:
        if len(word) == n:  # **
            lst = find_index(board, word[0])
            for coordinate in lst:
                row = coordinate[0]
                col = coordinate[1]
                new = [(row, col)]
                check_length_n(board, row, col, word[len(board[row][col]):], new, words, n,total)

    return total

def find_length_more_than_n_words(n: int, board: Board, words: Iterable[str]) -> List[Path]:
    new = []
    total=[]
    for word in words:
        if len(word) >= n:
            for k in range(1,len(word)):
                lst = find_index(board, word[0:k])
                for coordinate in lst:
                    row = coordinate[0]
                    col = coordinate[1]
                    new = [(row, col)]
                    check_length_n(board, row, col, word[len(word[0:k]):], new, words, n,total)
    return total


def max_score_paths(board, words):
    words_paths_dict = {}
    for path in find_length_more_than_n_words(1, board, words) :
        word = ''
        for cell in path:
            row, col = cell
            word += board[row][col]
        words_list = [word for word,path in words_paths_dict.keys()]
        if word not in words_list :
            words_paths_dict[(word, tuple(path))] = len(path) ** 2
        else:
            for key in words_paths_dict.keys():
                if key[0] == word :
                    word_key = key
            if len(path)**2 > words_paths_dict[word_key]:
                del words_paths_dict[word_key]
                words_paths_dict[(word,tuple(path))] = len(path) ** 2
    result = list(words_paths_dict.keys())
    result_as_lists = [list(coords) for word, coords in result]
    return result_as_lists


def max_score_helper(board,words_paths_dict):
    score = 0
    for path in max_score_paths(board):
        score += len(path)**2


if __name__ == '__main__':
    """with open('boggle_dict.txt', 'r', encoding='utf-8') as foalder:
         words: list[str] = [word.strip() for word in foalder.readlines()]"""







"""import copy
from typing import List, Tuple, Iterable, Optional
import os
file_path='boggle_dict.txt'
if os.path.exists(file_path):
    with open('boggle_dict.txt', 'r', encoding='utf-8') as foalder:
        words = [word.strip() for word in foalder.readlines()]

Board = List[List[str]]
Path = List[Tuple[int, int]]

def find_all_valid_neighbors(board, row, col):
    result = []
    for i in range(-1, 2):
        for j in range(-1,2):
            if i == 0 and j == 0:
                continue
            new_row, new_col = row+i, col+j
            if 0 <= new_row < len(board) and 0 <= new_col < len(board):
                result.append((new_row, new_col))
    return result

def is_valid_path(board: Board, path: Path, words: Iterable[str]) -> Optional[str]:
    word = ""
    if len(path) == 0:
        return
    for i in range(1, len(path)):
        row = path[i][0]
        col = path[i][1]
        prev_row = path[i-1][0]
        prev_col = path[i-1][1]
        if 0 <= prev_row < len(board) and 0 <= prev_col < len(board[0]):
            if (prev_row, prev_col) in find_all_valid_neighbors(board, row, col):
                word += board[prev_row][prev_col]
                continue
            else:
                return
        else:
            return
    row = path[len(path)-1][0]
    col = path[len(path)-1][1]
    if row < 0 or row >= len(board) or col < 0 or col >= len(board[0]):
        return
    if len(path) > 0:
       word += board[path[len(path)-1][0]][path[len(path)-1][1]]
    if word in words:
        return word
def find_index(board,value):
    lst = []
    for i in range(len(board)):
        for j in range(len(board[0])):
            if board[i][j] == value[0:2] or board[i][j] == value[0]:
                lst.append((i, j))
    return lst


def check(board, row, col, word, new, words, n, total):
    if word == '':
        if is_valid_path(board, new, words) and len(new) == n:
            total.append(copy.deepcopy(new))
        return

    if row == len(board) or col == len(board[0]):
        return

    for neighbor in find_all_valid_neighbors(board, row, col):
        if board[neighbor[0]][neighbor[1]] == word[0: len(board[neighbor[0]][neighbor[1]])]:
            if neighbor in new:
                continue
            new.append(neighbor)
            check(board, neighbor[0], neighbor[1], word[len(board[neighbor[0]][neighbor[1]]):], new, words, n,total)
            new.pop()
    return


def find_length_n_paths(n: int, board: Board, words: Iterable[str]) -> List[Path]:
    new = []
    total = []
    for word in words:
        if len(word) >= n:
            lst = find_index(board, word)
        else:
            lst = find_index(board, word[0])

        if lst:
            for coordinate in lst:
                row = coordinate[0]
                col = coordinate[1]
                new.append((row, col))
                if len(board[row][col])==2:
                   check(board, row, col, word[2:], new, words, n, total)
                else:
                    check(board, row, col, word[1:], new, words, n, total)
                new = []
    return total


def check_length_n(board,row,col,word,new, words,n,total):
    if word == '':
        if is_valid_path(board, new, words):
            total.append(copy.deepcopy(new))
        return

    if row == len(board) or col == len(board[0]):
        return

    for neighbor in find_all_valid_neighbors(board, row, col):
        if board[neighbor[0]][neighbor[1]] == word[0: len(board[neighbor[0]][neighbor[1]])]:
            if neighbor in new:
                continue
            new.append(neighbor)
            check_length_n(board, neighbor[0], neighbor[1], word[len(board[neighbor[0]][neighbor[1]]):], new, words, n,total)
            new.pop()
    return


def find_length_n_words(n: int, board: Board, words: Iterable[str]) -> List[Path]:
    new = []
    total=[]
    for word in words:
        if len(word) == n:
            lst = find_index(board, word[0])
            for coordinate in lst:
                row = coordinate[0]
                col = coordinate[1]
                new = [(row, col)]
                check_length_n(board, row, col, word[1:], new, words, n,total)

    return total


def find_length_more_than_n_words(n: int, board: Board, words: Iterable[str]) -> List[Path]:
    new = []
    total=[]
    for word in words:
        if len(word) >= n:
            lst = find_index(board, word[0])
            for coordinate in lst:
                row = coordinate[0]
                col = coordinate[1]
                new = [(row, col)]
                check_length_n(board, row, col, word[1:], new, words, n,total)
            lst2 = find_index(board,word[0:2])
            for coordinate in lst2:
                row = coordinate[0]
                col = coordinate[1]
                new = [(row, col)]
                check_length_n(board, row, col, word[2:], new, words, n,total)

    return total


def max_score_paths(board, words):
    words_paths_dict = {}
    for path in find_length_more_than_n_words(1, board, words):
        word = ''
        for cell in path:
            row, col = cell
            word += board[row][col]
        words_list = [word for word,path in words_paths_dict.keys()]
        if word not in words_list:
            words_paths_dict[(word, tuple(path))] = len(path) ** 2
        else:
            for key in words_paths_dict.keys():
                if key[0] == word:
                    word_key = key
            if len(path)**2 > words_paths_dict[word_key]:
                del words_paths_dict[word_key]
                words_paths_dict[(word,tuple(path))] = len(path) ** 2
    result = list(words_paths_dict.keys())
    result_as_lists = [list(coords) for word, coords in result]
    return result_as_lists


def max_score_helper(board):
    score = 0
    for path in max_score_paths(board):
        score += len(path)**2

"""
if __name__ == '__main__':
    """with open('boggle_dict.txt', 'r', encoding='utf-8') as foalder:
         words: list[str] = [word.strip() for word in foalder.readlines()]"""