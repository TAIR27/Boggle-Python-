import tkinter as tki
import tkinter.messagebox

import boggle_board_randomizer
import ex11_utils
from PIL import Image, ImageTk, ImageFilter

from typing import Callable, Dict, List, Any

BUTTON_HOVER_COLOR = 'gray'
REGULAR_COLOR = 'lightgray'
BUTTON_ACTIVE_COLOR = 'slateblue'

BUTTON_STYLE = {"font": ("Courier", 30),
                "borderwidth": 1,
                "relief": tki.RAISED,
                "bg": REGULAR_COLOR,
                "activebackground": BUTTON_ACTIVE_COLOR}

class BoggleGUI:
    _buttons = []
    buttons_val=[]

    def __init__(self, board) -> None:

        # Construction of the main window
        self.board = board
        self.root = tki.Tk()
        self.root.title("My Boggle")
        self.root.resizable(False, False)
        self._main_window = self.root
        self.cur_word = ''
        self.button_stop = None
        self.timer_started = False
        self.stop_plaing=True

        # outer frame
        self._outer_frame = tki.Frame(self.root, bg=REGULAR_COLOR,
                                      highlightbackground=REGULAR_COLOR,
                                      highlightthickness=5)  # this give us the frame
        self._outer_frame.pack(side=tki.TOP, fill=tki.BOTH, expand=True)

        # the place of the word that the user build
        self._display_label = tki.Label(self._outer_frame, font=("Courier", 30),
                                        bg=REGULAR_COLOR, width=23, relief="ridge")
        self._display_label.pack(side=tki.TOP, fill=tki.BOTH)


        self._score = tki.Label(self._outer_frame, font=("Courier", 30),
                                        bg=REGULAR_COLOR, width=23, relief="ridge",text="SCORE: 0")

        self._score.pack(side=tki.BOTTOM, fill=tki.BOTH)


        # the place of all the buttons of the board
        self._lower_frame = tki.Frame(self._outer_frame)
        self._lower_frame.pack(side=tki.TOP, fill=tki.BOTH, expand=True)


        self._create_buttons_in_lower_frame()  # create the button
        #self._main_window.bind("<Key>", self._key_pressed)  # to connection every press to self._key_pressed function

        #black board before starting the game
        self.black_frame = tki.Frame(self._lower_frame, bg="black")
        self.black_frame.grid(row=0, column=0, rowspan=5, columnspan=4, sticky=tki.NSEW)


        #timer
        self.timer_seconds = 180
        self.timer_label = tki.Label(self.root, text=f"Time: {self.timer_seconds} seconds")
        self.timer_label.pack()




    def close_window(self):
        # function that closes the window
        self._main_window.destroy()


    def start_timer(self):
        # function that starts timer
        self.button_start.unbind('<Button-1>')
        self.black_frame.grid_forget()
        if self.timer_seconds == 0 and self.stop_plaing==True:
            self.button_start.unbind('<Button-1>')
            self.timer_label.config(text="Time's up!")
        else:
            if self.timer_started:
                return
            self.timer_started = True
            self.timer_seconds -= 1
            self.timer_label.config(text=f"Time: {self.timer_seconds} seconds")
            self.root.after(1000, self.continue_timer)

    def continue_timer(self):
        if self.timer_seconds == 0:
            for button in self._buttons:
                 if button[0] != 'END':

                     button[3].config(state=tki.DISABLED)
                     #button[3].unbind('<Button-1>')
                 else:
                    return True

            self.timer_label.config(text="Time's up!")
            return
        else:
            self.timer_seconds -= 1
            self.timer_label.config(text=f"Time: {self.timer_seconds} seconds")
            self.root.after(1000, self.continue_timer)
            return

    def end_the_game_or_not(self):
        # function that asks the user if he wants to replay yes/no
        return tki.messagebox.askyesno("Replay?", "Do you want to replay?")

    # run the event loop
    def run(self) -> None:
        self._main_window.mainloop()

    #  controls what is displayed on the screen
    def set_display(self, display_text: str) -> None:
        self._display_label["text"] = display_text

    def set_score(self, new_score: str) -> None:
        self._score["text"] = str(new_score)

    def set_button_command(self, button: tuple, cmd: Callable[[], None]) -> None:

        for i in range(len(self._buttons)):
            if self._buttons[i][3] == button[3]:
                self._buttons[i][3].configure(command=cmd)
                return


    def get_button_val(self) :
        return self.buttons_val

    def _create_buttons_in_lower_frame(self) -> None:

        for i in range(4):
            tki.Grid.columnconfigure(self._lower_frame, i, weight=1)  # type: ignore

        for i in range(5):
            tki.Grid.rowconfigure(self._lower_frame, i, weight=1)  # type: ignore

        board_button = [[None for _ in range(len(self.board[0]))] for _ in range(len(self.board))]

        for i in range(len(self.board)):
            for j in range(len(self.board[0])):
                # button = tkinter.Button(root, text=board[i][j], font=("Courier", 10))
                button_text = f"Button {i + 1}-{j + 1}"
                self._make_button(self.board[i][j],i,j)
                #board_button[i][j] = tki.Button(root, text=board[i][j])
                #board_button[i][j].grid(row=i, column=j)

        self.button_stop = tki.Button(self._lower_frame, text="PRESS", **BUTTON_STYLE)
        self.button_stop.grid(row=5, column=0, rowspan=5, columnspan=2, sticky=tki.NSEW)
        self.button_stop.bind('<Button-1>', lambda e, i=5, j=0: self.pressed_button('PRESS', i,j))
        self._buttons.append(('PRESS',5,0,self.button_stop))

        self.button_start = tki.Button(self._lower_frame, text='START', **BUTTON_STYLE)
        self.button_start.grid(row=5, column=2, rowspan=5, columnspan=1, sticky=tki.NSEW)
        self.button_start.bind('<Button-1>', lambda e, i=5, j=6: self.start_timer())
        self._buttons.append(('START', 5, 6, self.button_start))

        self.button_end = tki.Button(self._lower_frame, text='END', **BUTTON_STYLE)
        self.button_end.grid(row=5, column=3, rowspan=5, columnspan=1, sticky=tki.NSEW)
        #self.button_end.bind('<Button-1>', lambda e, i=5, j=6: self.end_the_game_or_not())
        self._buttons.append(('END', 5, 6, self.button_end))

    def pressed_button(self,e, row, col):
        if e == 'PRESS':
            self.cur_word = ''
        else:
            self.cur_word += self.board[row][col]
        self.set_display(self.cur_word)

    def get_cur_word(self):
        return self.cur_word

    def set_cur_word(self):
         self.cur_word = ''

    def _make_button(self, button_char: str, row: int, col: int ,
                     rowspan: int = 1, columnspan: int = 1) -> tki.Button:
        button = tki.Button(self._lower_frame, text=button_char, **BUTTON_STYLE)
        button.grid(row=row, column=col, rowspan=rowspan, columnspan=columnspan, sticky=tki.NSEW)
        button.bind('<Button-1>', lambda e, i=row, j=col: self.pressed_button(e, i, j))

        self.buttons_val.append((button_char,row,col)) #*****************************
        self._buttons.append((button_char,row,col,button))

        def _on_enter(event: Any) -> None:
            button['background'] = BUTTON_HOVER_COLOR

        def _on_leave(event: Any) -> None:
            button['background'] = REGULAR_COLOR

        button.bind("<Enter>", _on_enter)
        button.bind("<Leave>", _on_leave)
        return button

    def _simulate_button_press(self, button: tuple) -> None:
        """make a button light up as if it is pressed,
        and then return to normal"""
        name, row, col = button
        button["bg"] = BUTTON_ACTIVE_COLOR
        # or just (row,col)?

        def return_button_to_normal() -> None:
            # find which widget the mouse is pointing at:
            x, y = self._main_window.winfo_pointerxy()
            widget_under_mouse = self._main_window.winfo_containing(x, y)
            # change color accordingly:
            if widget_under_mouse is button:
                button["bg"] = BUTTON_HOVER_COLOR
            else:
                button["bg"] = REGULAR_COLOR

        button.invoke()  # type: ignore
        button.after(100, func=return_button_to_normal)

if __name__ == "__main__":
    board = boggle_board_randomizer.randomize_board()
    cg = BoggleGUI(board)
    cg.set_display("YOUR WORD")
    cg.set_score("0")
    cg.run()


