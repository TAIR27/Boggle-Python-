from typing import Callable

import boggle_board_randomizer
from boggle_model import BoggleModel
from boggle_gui import BoggleGUI

class BoggleController:
    def __init__(self) -> None:
        self.board = boggle_board_randomizer.randomize_board()
        self._gui = BoggleGUI(self.board)
        self._model = BoggleModel(self.board)
        for button in self._gui._buttons:
            action = self.create_button_action(button)
            self._gui.set_button_command(button, action)


    def create_button_action(self, button: tuple) -> Callable[[], None]:
        def fun() -> None:
            if button[0] == 'END':
                if not self._gui.end_the_game_or_not():
                    self._gui.stop_plaing=False
                    self._gui.close_window()
                    return
                else:
                    self.start_new_game()
                return
            self._model.type_in(button)
            self._gui.set_display(self._model.get_display())
            self._gui.set_score(self._model.print_words_found())

        return fun
    def run(self) -> None:
        self._gui.run()

    def start_new_game(self):
        self.board = boggle_board_randomizer.randomize_board()
        self._gui = BoggleGUI(self.board)
        self._model = BoggleModel(self.board)
        for button in self._gui._buttons:
            action = self.create_button_action(button)
            self._gui.set_button_command(button, action)

if __name__ == "__main__":
    game1 = BoggleController()
    game1.run()




